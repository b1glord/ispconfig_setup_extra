# wp-ispconfig

The WordPress interface for ISPConfig – Hosting Control Panel. An excelent Open Source, transparent, free Server Manager.

As a remote user, with WP-ISPConfig plugin you can manage new account and client setup features of your ISPConfig 3 – Hosting Control Panel.

With WP-ISPConfig you can have WordPress installed on the same host, or in a remote host, and add what every new client needs all-in-one click.

This means the Client, DNS, Domain (website), FTP user, email Domain and mailbox, all just with minimal input and no complicated setup.

All you have to do is just activate and type in a few lines of settings.